const express = require("express");
const app = express();
const name="xyz";   
const indexRouter=require("./Routes/index-route");
// const userRouter=require("./Routes/user-route.js");
const cors=require("cors");


app.use(cors({allowOrigin:true,origin:"*"}));
app.use("/", indexRouter);
// app.use("/user", userRouter);

// function getDataMiddleware(value) {
// if (value){
//     return true;
// } else {
//     return false;
// } }
// app.get("/", function(req, res){
//     console.log("name=", name);
//     //res.end({message:"Request Getting Successfully", name: name});
//     res.redirect("/Home");
// });

// app.get("/", function(req, res){
//     res.send("Hello World, Welcome to the Express server");
// }); 
// app.get("/Home", function(req, res){
//     res.send("<h1>Hello All, Welcome to my Home Page</h1>");
// });
// app.get("/Contact", function(req, res){
//     res.send("Hello All, Welcome to my Contact Page");
// });
// app.get("/About", function(req, res){
//     res.send("Hello All, Welcome to my About Page");
// });

// //using Middleware Function
// app.get("/OrderDetails", function(req, res){
//     console.log("API request data with URL", req.url);
//     const isLogin = false;
//     const result= getDataMiddleware(isLogin);
// if (result){
//     res.send({message:"Order details fetched successfully", status:1});
// }else {
//         res.send({message:"Order details fetched failed", status:0});
// }
// });

app.listen(8000, function (){
    console.log("Server Running on Port 8000");
});