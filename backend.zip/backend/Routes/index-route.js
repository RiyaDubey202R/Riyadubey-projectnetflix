const express= require("express");
const multer = require("multer");
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'C:/Users/hp/Desktop/NewReactPractice/frontend/public/uploads')
    },
    filename: function (req, file, cb) {
    //   const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      cb(null, file.originalname)
    }
  })
const upload = multer({storage:storage});
const router = express.Router();
const indexController=require("../controllers/index.js");

//API Get
router.get("/", indexController.rootApi);
router.get("/getUserDetails/:email", indexController.userDetailsApi);
router.get("/getAllUser", indexController.getAllUserApi);
router.get("/userDelete/:email", indexController.userDeleteApi);

// API Post
router.post("/register", upload.single(), indexController.registerApi);
router.post("/login", upload.single(), indexController.userLoginApi);
router.post("/forget", upload.single(), indexController.forgetApi);
router.post("/otp-verify", upload.single(), indexController.otpVerifyApi);
router.post("/reset-password", upload.single(), indexController.resetPasswordApi);

router.post("/updateUserDetails/:email", upload.single(), indexController.updateUserApi);
router.post("/inactiveUser/:email", upload.single(), indexController.inactiveUserApi);

//profile uploading api

router.post("/profileUpload/:email", upload.single("image"), indexController.profileUploadApi);



//user passcode validation api
router.post("/userPasscode/:email", upload.single(""), indexController.userPasscodeApi);


module.exports = router;