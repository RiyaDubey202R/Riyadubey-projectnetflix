const nodemailer = require("nodemailer");
async function sendMail(otp,email){
    var transport =nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        auth: {
          user: "riya2710rd@gmail.com",
          pass: "bbyh pxww iyah ignq"
        }
      });
    console.log("transport", transport);
    const info= await transport.sendMail({
        from: '"riya2710rd@gmail.com"',
        to: email,
        subject: "OTP ",
        text: "Hello user ",
        html: `<h1>hello user ${email} your otp is ${otp}</h1>`,
      });
      return info;
}

module.exports =sendMail