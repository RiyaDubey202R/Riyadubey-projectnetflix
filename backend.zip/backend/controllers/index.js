const dbConnect = require("../db/dbconfig");
const bcrypt = require("bcrypt");
const sendMail = require("../helper/sendMail");
const userDetailsApi = async function (req, res) {
  const email = req.params.email;
  console.log("email", email);
  const users = await dbConnect();
  const userDetails = await users.findOne({ email });
  if (userDetails) {
    res.send({ message: "User Details Fetched", status: 1, data: userDetails });
  } else {
    res.send({ message: "User Details not found", status: 0 });
  }
};

const getAllUserApi = async function (req, res) {
  const users = await dbConnect();
  const userDetails = await users.find().toArray();
  if (userDetails) {
    res.send({ message: "User Details Fetched", status: 1, data: userDetails });
  } else {
    res.send({ message: "User Details not found", status: 0 });
  }
};

const rootApi = async function (req, res) {
  res.send("Welcome to /");
};

//Post Register API
const registerApi = async function (req, res) {
  const { firstname, lastname, email, password, dob } = req.body;
  const hashPassword = bcrypt.hashSync(password, 12);
  console.log("hashPassword: ", hashPassword);
  if (email && password && firstname && lastname) {
    const users = await dbConnect(); //Users
    // const findUsers = await users.find().toArray();
    const findUsers = await users.findOne({ email });
    if (findUsers) {
      res.send({ message: "already registered", status: 0 });
    } else {
      const insertData = await users.insertOne({
        email,
        password: hashPassword,
        firstname,
        lastname,
        dob,
        credits: 1000,
      });
      if (insertData) {
        res.send({
          message:
            "Data Post at /register end point, Congrats-1000 has been credited to your account",
          status: 1,
          firstname: firstname,
          lastname: lastname,
          email: email,
          password: password,
          dob: dob,
          credits: 1000,
        });
      } else {
        res.send({
          message: "something went wrong or insert failed",
          status: 0,
        });
      }
    }
  } else {
    res.send({ message: "Please fill all required fields", status: 0 });
  }
};

const userLoginApi = async function (req, res) {
  const { email, password } = req.body;
  if (email && password) {
    const users = await dbConnect(); //Users
    // const findUsers = await users.find().toArray();
    const findUsers = await users.findOne({ email: email });
    if (findUsers) {
      bcrypt.compare(password, findUsers.password, function (err, result) {
        console.log("result", result);
        if (result) {
          res.send({ message: "login success", status: 1 });
        } else {
          res.send({ message: "password or email incorrect", status: 0 });
        }
      });
    } else {
      res.send({ message: "User not found please register first", status: 0 });
    }
  } else {
    res.send({ message: "please check email and password both", status: 0 });
  }
};
const forgetApi = async function (req, res) {
  console.log("Forget Password API Calling");
  const { username } = req.body;
  // const hashPassword=bcrypt.hashSync(password,12);
  const users = await dbConnect(); //Users
  const findUsers = await users.findOne({ email: username });
  if (findUsers) {
    const otpGenerator = require("otp-generator");
    const otp = otpGenerator.generate(4, {
      upperCaseAlphabets: false,
      specialChars: false,
      lowerCaseAlphabets: false,
    });
    console.log("otp", otp);
    const info = await sendMail(otp, username);
    if (info) {
      const updateData = await users.updateOne(
        { email: username },
        { $set: { otp: otp } }
      );
      if (updateData) {
        res.send({ message: "otp sent to your email address", status: 1 });
      } else {
        res.send({ message: "Password reset failed", status: 0 });
      }
    } else {
      res.send({ message: "not able to send otp", status: 0 });
    }
  } else {
    res.send({ message: "User not found!", status: 0 });
  }
};

const resetPasswordApi = async function (req, res) {
  console.log("Forget Password API Calling");
  const { username, password, cp } = req.body;
  const hashPassword = bcrypt.hashSync(password, 12);
  const users = await dbConnect(); //Users
  const findUsers = await users.findOne({ email: username });
  if (findUsers) {
    const updateData = await users.updateOne(
      { email: username },
      { $set: { password: hashPassword, cp: cp } }
    );
    if (updateData) {
      res.send({ message: "password reset successfully", status: 1 });
    } else {
      res.send({ message: "Password reset failed", status: 0 });
    }
  } else {
    res.send({ message: "User not found!", status: 0 });
  }
};

const otpVerifyApi = async function (req, res) {
  console.log("Forget Password API Calling");
  const { username, otp } = req.body;
  // const hashPassword=bcrypt.hashSync(password,12);
  const users = await dbConnect(); //Users
  const findUsers = await users.findOne({ email: username });
  if (findUsers) {
    if (findUsers.otp == otp) {
      res.send({ message: "verified successfully", status: 1 });
    } else {
      res.send({ message: "Otp is invaliud", status: 0 });
    }
  } else {
    res.send({ message: "User not found!", status: 0 });
  }
};

const updateUserApi = async function (req, res) {
  console.log("update user API Calling");
  const username = req.params.email;
  const { lastname, firstname, dob } = req.body;
  const users = await dbConnect(); //Users
  const findUsers = await users.findOne({ email: username });
  if (findUsers) {
    const updateData = await users.updateOne(
      { email: username },
      { $set: { dob, lastname, firstname } }
    );
    if (updateData) {
      res.send({ message: "user details reset successfully", status: 1 });
    } else {
      res.send({ message: "user details reset failed", status: 0 });
    }
  } else {
    res.send({ message: "User not found!", status: 0 });
  }
};

const inactiveUserApi = async function (req, res) {
  console.log("inactive user API Calling");
  const username = req.params.email;
  const users = await dbConnect(); //Users
  const findUsers = await users.findOne({ email: username });
  if (findUsers) {
    if (findUsers.status == "1") {
      const updateData = await users.updateOne(
        { email: username },
        { $set: { status: 0 } }
      );
      if (updateData) {
        res.send({ message: "user inactive/deleted successfully", status: 1 });
      } else {
        res.send({ message: "user inactive/deleted failed", status: 0 });
      }
    } else {
      const updateData = await users.updateOne(
        { email: username },
        { $set: { status: 1 } }
      );
      if (updateData) {
        res.send({ message: "user active successfully", status: 1 });
      } else {
        res.send({ message: "user active failed", status: 0 });
      }
    }
  } else {
    res.send({ message: "User not found!", status: 0 });
  }
};

// profile upload controller

const profileUploadApi = async (req, res) => {
  const email = req.params.email;
  console.log("req.file", req.file);
  const users = await dbConnect();
  const findUsers = await users.findOne({ email });
  if (findUsers) {
    const profileUpload = await users.updateOne(
      { email: email },
      { $set: { image: req.file.originalname } }
    );
    if (profileUpload) {
      res.send({ message: "profile uploaded successfully", status: 1 });
    } else {
      res.send({ message: "profile uploaded failed", status: 0 });
    }
  } else {
    res.send({ message: "user not found", status: 0 });
  }
};

const userDeleteApi = async (req, res) => {
  const username = req.params.email;
  const users = await dbConnect(); //Users
  const findUsers = await users.findOne({ email: username });
  if (findUsers) {
    const deleteData = await users.deleteOne({ email: username });
    if (deleteData) {
      res.send({ message: "user deleted successfully", status: 1 });
    } else {
      res.send({ message: "user deleted failed", status: 0 });
    }
  } else {
    res.send({ message: "User not found!", status: 0 });
  }
};

//userPasscodeApi
const userPasscodeApi = async (req, res) => {
  console.log("userPasscodeApi",req);
  
  const email = req.params.email;
  const passcode = req.body.passcode;

  console.log("userPasscodeApi",email,passcode);
  const users = await dbConnect(); //Users
  const findUsers = await users.findOne({ email: email });
  if (findUsers) {
    if (passcode === findUsers.dob) {
      res.send({ message: "verification successfully", status: 1 });
    } else {
      res.send({ message: "access denied", status: 0 });
    }
  } else {
    res.send({ message: "User not found!", status: 0 });
  }
};

module.exports = {
  userDetailsApi,
  rootApi,
  registerApi,
  forgetApi,
  userLoginApi,
  getAllUserApi,
  updateUserApi,
  userDeleteApi,
  inactiveUserApi,
  profileUploadApi,
  otpVerifyApi,
  resetPasswordApi,
  userPasscodeApi,
};
