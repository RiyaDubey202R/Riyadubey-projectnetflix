const {MongoClient} =require('mongodb');
// const url="mongodb://127.0.0.1:27017"
// const dbConnect=async()=>{
//        const client=new MongoClient(url);
//        const db=client.db("Netflix");
//        const collection=db.collection("Users");
//        return collection;
// }

// module.exports=dbConnect;

const mongoose =require('mongoose');
uri = "mongodb+srv://Netflix:XuwfEL62p5tLWO10@cluster0.mteab9d.mongodb.net/"
// const dbConnect=()=>{
//       return mongoose.connect(uri, {
//        useNewUrlParser: true,
//        useUnifiedTopology: true,
//       });
// };
const dbConnect=async()=>{
       const client=new MongoClient(uri);
       const db=client.db("NetflixDatabase");
       const collection=db.collection("User");
       return collection;
}

module.exports=dbConnect;