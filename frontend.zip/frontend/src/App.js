import logo from './logo.svg';
import './App.css';
import Register from './Register';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Login from './Login';
import User from './User';
import Navbar from './Navbar';
import Home from './Home';
import About from './About';
import NoPage from './NoPage';
import Dashboard from './Components/privatedashboard/Dashboard';
import Forgot from './Forgot';
import Footer from './Footer';
import Profile from './Profile';
import ClassComp from './ClassComp';

function App() {
  return (
  <BrowserRouter>
  <Routes>
    <Route path="/" element={<Navbar/>}>
    <Route index element={<Home/>}></Route>
    {/* <Route index element={<ClassComp/>}></Route> */}
    <Route path="register" element={<Register/>}></Route>
    <Route path="login" element={<Login/>}></Route>
    <Route path="about" element={<About/>}></Route>
    <Route path="home" element={<ClassComp/>}></Route>
    <Route path="profile" element={<Profile/>}></Route>
    <Route path="dashboard" element={<Dashboard/>}></Route>
    <Route path="forgot" element={<Forgot/>}></Route>
    <Route path="user/:email" element={<User/>}></Route>

    {/* <Route path="/" element={<Footer/>}> */}
    {/* </Route> */}
    </Route>
    <Route path="*" element={<NoPage/>}></Route>
  </ Routes>
  </BrowserRouter>
  );
}

export default App;