import React, { Component } from "react";
import ClassChild from "./ClassChild";

export default class ClassComp extends Component {
  constructor() {
    super();
    this.state = { name: "xyz", email: "email@gmail.com", status: 0 };
  }
  handleClick = () => {
    console.log("worked");
    if (this.state.status == 0) {
      this.setState({
        email: "abc@gmail.com",
        name: "Durgesh Prajapat",
        status: 1,
      });
    } else {
      this.setState({ name: "xyz", email: "email@gmail.com", status: 0 });
    }
  };
  render() {
    return (
      <div style={{ height: "500px", backgroundColor: "white" }}>
        ClassComp
        <h1>name:{this.state.name}</h1>
        <h1>email:{this.state.email}</h1>
        <button onClick={this.handleClick}>{this.state.status==0?"Change Email":"Revert"}</button>
        
        <br></br>
        <br></br>

        <ClassChild name="yellow" email="hello@email.com"/>
      </div>
    );
  }
}
