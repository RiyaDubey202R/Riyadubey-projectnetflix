import React, { useState } from "react";
import { Button, Drawer, Radio, Space } from 'antd';
import { Link } from "react-router-dom";
export default function SettingDrawer() {
    const [open, setOpen] = useState(false);
  const [placement, setPlacement] = useState('left');
  const showDrawer = () => {
    console.log("mouseover");
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  };
  const onChange = (e) => {
    setPlacement(e.target.value);
  };
  return (
    <div>
      {/* <Space> */}
        {/* <Radio.Group value={placement} onChange={onChange}>
          <Radio value="top">top</Radio>
          <Radio value="right">right</Radio>
          <Radio value="bottom">bottom</Radio>
          <Radio value="left">left</Radio>
        </Radio.Group> */}
        <div style={{width:"50px",height:"10px"}}>
        <Button type="primary" onMouseEnter={showDrawer} >
          +
        </Button>
        </div>
      {/* </Space> */}
      <Drawer
        title="My Settings"
        placement={placement}
        closable={false}
        onClose={onClose}
        open={open}
        key={placement}
        onMouseLeave={onClose}
        onClick={onClose}
      >
        <p><Link to="/profile">My Profile
                    </Link></p>
        <p>Enable Passcode</p>
        <p>Account Setting</p>
        <p>Help Center</p>
        <p>Privacy & Policies</p>
      </Drawer>
    </div>
  );
}