import React from 'react'

function PrimaryButton(props) {
  console.log(props.onClick);
  return (
    <button onClick={props.onClick} style={{color:props?.color, borderRadius:"10px",background:"blue",cursor:`${props?.disabledStatus?"not-allowed":"pointer"}`, marginLeft:"5px"}} disabled={props?.disabledStatus}>{props.title}</button>
  )
}
export default PrimaryButton
