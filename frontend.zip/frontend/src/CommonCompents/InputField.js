import React from 'react'

export default function InputField(props) {
  return (
    <div >
        <label htmlFor={props.name} style={{ color: "black", margin: "40px" }}>
          {props.title}{" "}
        </label>
        <input
          type={props.type}
          value={props.value}
          placeholder={props.placeholder}
        //   onChange={(e) => {
        //     setEmail(e.target.value);
        //   }}
        onChange={props.onChange}
        ></input>
    </div>
  )
}
