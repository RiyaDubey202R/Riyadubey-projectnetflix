import React, { useState, useEffect } from "react";
import axios from "axios";
import Button from "./Button";
import { Modal } from "antd";
import swal from "sweetalert";
import { Link, useNavigate } from "react-router-dom";
import { EyeOutlined, EyeInvisibleOutlined } from "@ant-design/icons";
export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [open, setOpen] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState(false);
  const [isValid, setIsValid] = useState(false);
  const [type, setType] = useState("password");
  const [isPasswordChanged, setIsPasswordChanged] = useState(false);

  const handleLogin = () => {
    console.log("handlelogin working");
    console.log("email on change", email, password);
    const formData = new FormData();

    formData.append("email", email);
    formData.append("password", password);
    axios
      .post("http://localhost:8000/login", formData)
      .then((res) => {
        console.log("backend response: ", res);
        if (res?.data?.status == 1) {
          // showModal();
          setMessage(res?.data?.message);
          setStatus(true);
          swal({
            position: "center",
            icon: "success",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
          localStorage.setItem("email", email);

          navigate("/dashboard");
        } else {
          // showModal();
          swal({
            position: "center",
            icon: "warning",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
          setMessage(res?.data?.message);
        }
        // setUser(res.data.data);
      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };

  const showModal = () => {
    setOpen(true);
  };
  const handleOk = () => {
    setConfirmLoading(true);
    setOpen(false);
    setConfirmLoading(false);
    if (status) {
      localStorage.setItem("email", email);
      navigate("/dashboard");
    }
  };

  const handleCancel = () => {
    console.log("Clicked cancel button");
    setOpen(false);
  };

  const handleShow = (e) => {
    if (type == "password") {
      setType("text");
    } else {
      setType("password");
    }
  };

  const validateEmail = (email) => {
    return email.match(
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
    setIsPasswordChanged(true);
  };

  const handlePasswordBlur = () => {
    setIsPasswordChanged(false);
  };

  const handlePasswordFocus = () => {
    setIsPasswordChanged(true);
  };

  useEffect(() => {
    var value = validateEmail(email);
    if (value) {
      setIsValid(true);
    } else {
      setIsValid(false);
    }
  }, [email]);
  return (
    <center>
      <div style={{ color: "black", height: "500px" }}>
        <h1 className="text-3xl font-bold underline bg-green-500">Login</h1>
        <br />
        <label htmlFor="email" style={{ color: "black", margin: "40px" }}>
          Email{" "}
        </label>
        <input
          type="text"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
          }}
        ></input>
        <br />
        <label htmlFor="password" style={{ color: "black", margin: "41px" }}>
          Password
        </label>
        <input
          type={type}
          length={7}
          value={password}
          onChange={handlePasswordChange}
          onBlur={handlePasswordBlur}
          onFocus={handlePasswordFocus}
        ></input>
        <button
          style={{ backgroundColor: "rgb(121 102 102)", color: "black" }}
          onClick={handleShow}
          disabled={password?.length > 0 ? false : true}
        >
          {type == "password" ? <EyeOutlined /> : <EyeInvisibleOutlined />}
        </button>

        <br />
        <Button
          title="Login"
          onClick={handleLogin}
          color="blue"
          disabledStatus={
            email.length > 0 &&
            isValid &&
            password.length > 0 &&
            password.length <= 8
              ? false
              : true
          }
        />
        <Link to="/forgot">
          <Button
            title="forgot"
            onClick={handleLogin}
            color="red"
            disabledStatus={false}
          />
        </Link>
        {/* <Button type="primary" onClick={showModal}>
        Open Modal with async logic
      </Button> */}
        <Modal
          title={message}
          open={open}
          onOk={handleOk}
          confirmLoading={confirmLoading}
          onCancel={handleCancel}
        >
          {/* <p>{modalText}</p> */}
        </Modal>
        <br />
        <>
          {isValid ? (
            <span style={{ color: "green" }}>{email} Email is valid</span>
          ) : (
            <span style={{ color: "red" }}>{email} Email is not valid</span>
          )}
          <br />
          {isPasswordChanged ? (
            password?.length > 0 && password?.length < 8 ? (
              <span style={{ color: "green" }}> Password is valid</span>
            ) : (
              <span style={{ color: "red" }}>
                {" "}
                Password should be less than 8 character
              </span>
            )
          ) : (
            ""
          )}
        </>
      </div>
    </center>
  );
}
