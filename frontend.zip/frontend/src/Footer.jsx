import {React, width}from "react";
// import {fontSize} from 'react';
import { Collapse, Divider} from "antd";

import FAQ from "./Components/FAQ/FAQ";

export default function Footer() {
  return (
    <>
    <FAQ/>
      <br/>
      <hr
        style={{
          Color: "grey",
          height: "5px",
          backgroundColor: "grey",
          marginTop: "-10px",
        }}
      />
      <center>
      <div style={{ backgroundColor: "black", height: "auto", marginTop:"-21px", marginBottom:"-20px", color:"wheat" }}>
        <ul
          style={{
            fontSize: "8px",
            display: "inline-block",
            marginLeft: "10px",
            listStyle: "none",
          }}
        >
          <li>FAQ</li>
          <li>Investors Relations</li>
          <li>Privacy</li>
          <li>Speed Test</li>
        </ul>
        <ul
          style={{
            fontSize: "8px",
            display: "inline-block",
            marginLeft: "10px",
            listStyle: "none",
          }}
        >
          <li>Help Centre</li>
          <li>Jobs</li>
          <li>Cookies Preference</li>
          <li>Legal Notice</li>
        </ul>
        <ul
          style={{
            fontSize: "8px",
            display: "inline-block",
            marginLeft: "10px",
            listStyle: "none",
          }}
        >
          <li>Account</li>
          <li>Ways to Watch</li>
          <li>Corporate Information</li>
          <li>Only on Netflix</li>
        </ul>
      </div>
      </center>
    </>
  );
}
