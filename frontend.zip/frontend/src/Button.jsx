import React from 'react'

function Button(props) {
  return (
    <button onClick={props.onClick} style={{color:"white", borderRadius:"10px",background:props.color,cursor:`${props?.disabledStatus?"not-allowed":"pointer"}`, marginLeft:"5px"}} disabled={props?.disabledStatus}>{props.title}</button>
  )
}
export default Button
