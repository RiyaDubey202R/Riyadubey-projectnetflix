import React, { useState, useEffect } from "react";
import axios from "axios";
import Login from "./Login";
import Button from "./Button";
import { BoldOutlined } from "@ant-design/icons";
import swal from "sweetalert";
import InputField from "./Components/Input/InputField";
import { useNavigate } from "react-router-dom";
export default function Register() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [dob, setDob] = useState("");
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [newEmail, setNewEmail] = useState("");
  console.log("newEmail form login components", newEmail);
  const handleRegister = () => {
    console.log("email on change", email, password, lastname, firstname, dob);
    const formData = new FormData();
    formData.append("firstname", firstname);
    formData.append("lastname", lastname);
    formData.append("email", email);
    formData.append("password", password);
    formData.append("dob", dob);
    axios
      .post("http://localhost:8000/register", formData)
      .then((res) => {
        console.log("backend response: ", res);
        if (res?.data?.status == 1) {
          // getAllUsersDetails();
          // alert("success");
          swal({
            position: "center",
            icon: "success",
            title: res.data?.message,
            showConfirmButton: false,
            timer: 1500,
          });
          navigate("/login");
        } else {
          swal({
            position: "center",
            icon: "error",
            title: res.data?.message,
            showConfirmButton: false,
            timer: 1500,
          });
        }
      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };

  const [user, setUser] = useState([]);
  const getAllUsersDetails = async () => {
    axios
      .get("http://localhost:8000/getAllUser")
      .then((res) => {
        console.log("backend response: ", res?.data?.data);
        setUser(res.data.data);
      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };

  return (
    <>
      <center>
        <div style={{ color: "black", backgroundColor: "thistle" }}>
          <b>Register</b>
          <br />
          <label htmlFor="email">Email</label>
      <input
        type="text"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value);
        }}
      ></input>
          {/* <InputField
            type="text"
            name="email"
            title="Email"
            value={email}
            onchange={(e) => {
              setEmail(e.target.value);
            }}
          /> */}
          <br />
          <label htmlFor="firstname">Firstname</label>
          <input
            type="text"
            value={firstname}
            onChange={(e) => {
              setFirstname(e.target.value);
            }}
          ></input>
          <br />
          <label htmlFor="lastname">Lastname</label>
          <input
            type="text"
            value={lastname}
            onChange={(e) => {
              setLastname(e.target.value);
            }}
          ></input>
          <br />
          <label htmlFor="password">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
          ></input>
          <br />
          <label htmlFor="dob">DOB</label>
          <input
            type="date"
            value={dob}
            onChange={(e) => {
              setDob(e.target.value);
            }}
          ></input>
          <br />
          <br />
          <Button
            title="Register"
            onClick={handleRegister}
            color="rgb(121 102 102)"
            disabledStatus={
              email.length > 0 &&
              // password.length > 0 &&
              password.length <= 8 &&
              firstname.length > 0 &&
              lastname.length > 0 &&
              dob.length > 0
                ? false
                : true
            }
          />
        </div>
      </center>
    </>
  );
}
