import React, { useState } from "react";
import Button from "./Button";

export default function Card() {
  const [name, setName] = useState("xyz");
  const [amount, setAmount] = useState();
  const [wallet,setWallet] = useState(parseInt(localStorage.getItem("wallet"))>0?parseInt(localStorage.getItem("wallet")):0);
  const [isAdd,setIsAdd] = useState(false);
  const handleCredit = () => {
    console.log("handle credit function working");
    // setName(`abc${amount + 1}`);
    setWallet(wallet+Number(amount));
    setAmount("");
    localStorage.setItem("wallet", wallet+Number(amount));
  };
  const handleDebit = () => {
    console.log("handle debit function working");
    // setName(`xyz${amount - 1}`);
    setWallet(wallet-Number(amount));
    setAmount("");
    localStorage.setItem("wallet", wallet-Number(amount));
  };
  const handleAdd=()=>{
    setIsAdd(true);
  }
  const handleRemove=()=>{
    setIsAdd(false);
  }
  return (
    <>
      {isAdd?<div><h1>{name}</h1>
      <h1>Wallet Amount: {wallet}</h1>

      <input type="text" value={amount} name="amount" onChange={(e)=>setAmount(e.target.value)} />
      <br />
      <br />
      <Button onClick={handleCredit} title="Credit" color="green" disabledStatus={amount<=0?true:false} />
      <Button onClick={handleDebit} title="Debit" color="red" disabledStatus={amount<=0?true:false} />
      </div>:""}
      {/* <button onClick={handleCredit}>credit</button> */}
      <br/>
      <br/>
      <Button onClick={handleAdd} title="Add" color="Blue"/>
      <Button onClick={handleRemove} title="Remove" color="Red
      "/>

    </>
  );
}
