import React, { useReducer } from 'react'


export default function Dashboard() {
  const initialValue={
    count:0,
  };

const reducer=(state,action)=>{
  console.log("action state",action,state);
   switch(action.type){
     case "Increament":{
      return {...state,count:state.count+1};
     }
     case "Decreament":{
      return {...state,count:state.count-1};
     }
     case "ADDBY2":{
      return {...state,count:state.count+2};
     }
     default:{
      return state+1;
     }
   }
}

  const [state,dispatch]=useReducer(reducer,initialValue);
  console.log("state: ",state);
  return (
    < div style={{color:"black"}}>
    <center><div style={{backgroundColor:"wheat",height:"500px"}}>Dashboard
    <h1>{state.count}</h1>
    <button onClick={()=>{dispatch({type:"Increament"})}}>+</button>
    <button onClick={()=>{dispatch({type:"Decreament"})}}>-</button>
    <button onClick={()=>{dispatch({type:"ADDBY2"})}}>add by 2</button>

    </div></center>
    </div>
  )
}
