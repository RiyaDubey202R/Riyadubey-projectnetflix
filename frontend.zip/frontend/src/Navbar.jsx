import React, { useEffect, useState } from "react";
import { Link, Outlet, redirect, useNavigate } from "react-router-dom";
import ima from "../src/uploads/ship.jpg";
//external css linking
import "./App.css";
import { Select } from "antd";
import { UserOutlined } from "@ant-design/icons";
import Footer from "./Footer";
import axios from "axios";
import Drawer from "./CommonCompents/Drawer";
export default function Navbar() {
  const navigate = useNavigate();
  const [image, setImage] = useState("");
  const email = localStorage.getItem("email");
  console.log("email", email);
  const handleLogout = async () => {
    console.log("working");
    localStorage.removeItem("email");
    setImage("");
    navigate("/login");
  };
  const [user, setUser] = useState([]);
  const getAllUsersDetails = async () => {
    axios
      .get("http://localhost:8000/getAllUser")
      .then((res) => {
        console.log("backend response: ", res?.data?.data);
        setUser(res.data.data);
      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };
  const optionsData = user.map((item) => {
    return {
      value: item._id,
      label: `${item.firstname + item.lastname}`,
    };
  });

  const getSpecificUsersDetails = () => {
    console.log("specific users details");
    axios
      .get(`http://localhost:8000/getUserDetails/${email}`)
      .then((res) => {
        console.log("backend response: ", res?.data);
        setImage(res?.data?.data?.image);
      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };
  useEffect(() => {
    getAllUsersDetails();
    getSpecificUsersDetails();
  }, [email]);

  console.log("image", image);
  return (
    <>
      <div style={{ backgroundColor: "white" }}>
        <nav>
          <div>
            <div style={{ backgroundColor: "black" }} id="navbarNav">
              <img
                src="https://assets.stickpng.com/images/580b57fcd9996e24bc43c529.png"
                alt="Logo"
                style={{
                  height: "50px",
                  marginTop: "10px",
                  marginInline: "14px",
                  marginBottom: "-44px",
                }}
              />
              <ul
                type="none"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  padding: "0.5px",
                  alignContent: "center",
                  marginTop:"19px"
                }}
              >
                <div id="navbar">
                <li
                  className="li-item"
                  style={{ marginRight: "20px", color: "wheat" }}
                >
                  <Link to="/">Home</Link>
                </li>
                {email ? (
                  ""
                ) : (
                  <li className="li-item" style={{ marginRight: "20px" }}>
                    <Link to={!email ? `/login` : ""}>
                      {email ? "" : "Login"}
                    </Link>
                  </li>
                )}

                {email ? (
                  ""
                ) : (
                  <li className="li-item" style={{ marginRight: "20px" }}>
                    <Link to={!email ? `/register` : ""}>
                      {email ? "" : "Register"}
                    </Link>
                  </li>
                )}
                <li style={{ marginRight: "20px" }}>
                  <Link to="/About">About</Link>
                </li>

                {email && (
                  <li style={{ marginRight: "20px" }}>
                    {/* <Link to="/About">About</Link> */}
                    <Select
                      showSearch
                      style={{
                        width: 200,
                        height: "25px",
                        fontSize: "10px",
                      }}
                      allowClear
                      placeholder="Search to Select"
                      optionFilterProp="children"
                      filterOption={(input, option) =>
                        option.label
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0 ||
                        option.label
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                      filterSort={(optionA, optionB) =>
                        (optionA?.label ?? "")
                          .toLowerCase()
                          .localeCompare((optionB?.label ?? "").toLowerCase())
                      }
                      options={optionsData}
                    />
                  </li>
                )}

                {email && (
                  <li style={{ marginRight: "20px" }}>
                    {image ? (
                      <img
                        src={`/uploads/${image}`}
                        alt="image"
                        width="18px"
                        height="18px"
                        style={{ borderRadius: "9px", marginTop: "3px" }}
                      />
                    ) : (
                      <div
                        style={{
                          backgroundColor: "red",
                          borderRadius: "9px",
                          marginTop: "3px",
                          width: "18px",
                          height: "18px",
                        }}
                      >
                        <UserOutlined />
                      </div>
                    )}
                  </li>
                )}

                <li className="li-item" style={{ marginRight: "20px" }}>
                  {email ? (
                    <button
                      onClick={handleLogout}
                      style={{
                        backgroundColor: "rgb(121 102 102)",
                        color: "wheat",
                      }}
                    >
                      Logout
                    </button>
                  ) : (
                    ""
                  )}
                </li>

                {email ? (
                  <li className="li-item" style={{ marginRight: "20px" }}>
                    <Drawer />
                  </li>
                ) : (
                  ""
                )}
                </div>
              </ul>
              <div style={{ marginLeft: "850px", marginTop: "-45px" }}>
                <select
                  name="Language"
                  id="Language"
                  style={{
                    height: "15px",
                    fontSize: "10px",
                    backgroundColor: "wheat",
                    filter: "opacity",
                    marginLeft: "45px",
                    backgroundColor: "transparent",
                    border: "1px solid",
                    color: "wheat",
                  }}
                >
                  <option value="English" style={{ color: "black" }}>
                    English
                  </option>
                  <option value="हिन्दी" style={{ color: "black" }}>
                    हिन्दी
                  </option>
                </select>
              </div>
            </div>
          </div>
        </nav>
        <Outlet />
        <Footer style={{ position: "fixed" }} />
      </div>
    </>
  );
}
