import React, { useEffect, useState } from "react";
import swal from "sweetalert";
import axios from "axios";
import InputField from "./CommonCompents/InputField";
import { Button } from "antd";
import PrimaryButton from "./CommonCompents/Button";
import api from "./utils/api";

export default function Profile() {
  const [image, setImage] = useState("");
  const [user, setUser] = useState([]);
  const [firstName, setFirstName] = useState("");
  const [btnStatus,setBtnStatus] = useState(true);

  const [lastname, setLastName] = useState("");

  const [dob, setDob] = useState("");

  console.log(image);
  const email = localStorage.getItem("email");

  const handleImage = (e) => {
    e.preventDefault();
    if (
      e.target.files[0].type == "image/jpeg" ||
      e.target.files[0].type == "image/png"
    ) {
      setImage(e.target.files[0]);
      const formData = new FormData();
      formData.append("image", e.target.files[0]);
      axios
        .post(`http://localhost:8000/profileUpload/${email}`, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          console.log(response);
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      // alert("warning");
      swal({
        position: "center",
        icon: "warning",
        title: "image should be jpg/png format",
        showConfirmButton: false,
        timer: 1500,
      });
    }
  };

const handleLastname = (e) => {
  setLastName(e.target.value);
  setBtnStatus(false);
}
const handleFirstname = (e) => {
  setFirstName(e.target.value);
  setBtnStatus(false);
}
const handleDob = (e) => {
  setDob(e.target.value);
  setBtnStatus(false);
}

  const getAllUsersDetails = async () => {
    axios
      .get(`http://localhost:8000/getUserDetails/${email}`)
      .then((res) => {
        console.log("backend response: ", res?.data?.data);
        const us = [res?.data?.data];
        setUser(us);
        setLastName(us[0]?.lastname);
        setFirstName(us[0]?.firstname);
        setDob(us[0]?.dob);

      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };
  useEffect(() => {
    getAllUsersDetails();
  }, []);

  const handleUpdate=async()=>{
    console.log("clicked update");
    console.log("edit api call");
    const formData = new FormData();
    formData.append("firstname", firstName);
    formData.append("lastname", lastname);
    formData.append("dob", dob);
    const url=`http://localhost:8000/updateUserDetails/${email}`
    const res=await api(url,formData);//1
    console.log("res",res);
    if(res==1){
        swal({
            position: "center",
            icon: "success",
            title: "Updated successfully",
            showConfirmButton: false,
            timer: 3000,
          });
    }
    else{
        swal({
            position: "center",
            icon: "warning",
            title: "Something went wrong!",
            showConfirmButton: false,
            timer: 3000,
          });
    }
  }
  return (
    <>
      <div>
        <label>
          <input
            type="file"
            name="image"
            onChange={(e) => handleImage(e)}
          ></input>
        </label>
      </div>
      <div>
        <InputField name="firstname" title="First Name" type="text" value={firstName} onChange={(e)=>handleFirstname(e)}/>
      </div>
      <div>
        <InputField name="lastname" title="Last Name" type="text" value={lastname} onChange={(e)=>handleLastname(e)}  />
      </div>
      <div>
        <InputField name="dob" title="DOB" type="date" value={dob} onChange={(e)=>handleDob(e)}/>
      </div>

      <div>
        <PrimaryButton color="white" title="Update" disabledStatus={btnStatus} onClick={()=>handleUpdate()}/>
      </div>
    </>
  );
}
