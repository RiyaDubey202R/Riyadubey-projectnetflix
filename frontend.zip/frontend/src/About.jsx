import React from "react";
import marginLeft from "react";

export default function About() {
  const user = [
    // {
    //   id: 1,
    //   name: "John",
    //   animals: ["Cat", "Dog"],
    // },
    // {
    //   id: 2,
    //   name: "Brock",
    //   animals: ["Cow", "Goat"],
    // },
    // {
    //   id: 3,
    //   name: "Khali",
    //   animals: ["Dog", "Cow"],
    // },
  ];
  return (
    <>
      {/* <center><div>
      <b>About</b>
      {user.map((item) => {
        return (
          <>
            <h2>Name:{item.name}</h2>
            {item.animals.map((items) => {
                return(
                    <h3>Animals:{items}</h3>
                )
            })}
          </>
        );
      })}
    </div></center> */}
      <div style={{ backgroundColor: "black", color: "white" }}>
        <div style={{ fontSize: "20px", marginLeft: "60px", color: "grey" }}>
          <b>Enjoy on your TV</b>
        </div>
        <div style={{ fontSize: "10px", marginLeft: "60px" }}>
          Watch on smart TVs, PlayStation, Xbox, Chromecast, Apple,
          <br />
          TV, Blu-ray players and more.
        </div>
        <video
          autoPlay playsInline
          muted
          style={{ height: "100px", marginLeft: "400px", marginTop: "-50px" }}
          src="https://assets.nflxext.com/ffe/siteui/acquisition/ourStory/fuji/desktop/video-tv-in-0819.m4v"
        ></video>
      </div>
      <hr
        style={{
          Color: "gray",
          height: "5px",
          backgroundColor: "grey",
          marginTop: "0px",
        }}
      />
      <div style={{ backgroundColor: "black", color: "white", marginTop:"-9px" }}>
        <div style={{ fontSize: "20px", marginLeft: "450px", color: "grey"}}>
          <b>
            Download your shows to
            <br />
            watch offline
          </b>
        </div>
        <div style={{ fontSize: "10px", marginLeft: "450px" }}>
          Save your favourites easily and always have something to
          <br />
          watch.
        </div>
        <img
          src="https://assets.nflxext.com/ffe/siteui/acquisition/ourStory/fuji/desktop/mobile-0819.jpg"
          alt="Girl"
          style={{ height: "150px", marginTop: "-80px", marginLeft: "130px"}}
        />
      </div>
      <hr
        style={{
          Color: "gray",
          height: "5px",
          backgroundColor: "grey",
          marginTop: "0px",
        }}
      />
      <div style={{ backgroundColor: "black", color: "white", marginTop:"-9px" }}>
        <div style={{ fontSize: "20px", marginLeft: "60px", color: "grey" }}>
          <b>Watch everywhere</b>
        </div>
        <div style={{ fontSize: "10px", marginLeft: "60px" }}>
          Stream unlimited movies and TV shows on your phone,
          <br />
          tablet, laptop, and TV.
        </div>
        <video
          autoPlay playsInline
          muted
          style={{ height: "100px", marginLeft: "400px", marginTop: "-50px" }}
          src="https://assets.nflxext.com/ffe/siteui/acquisition/ourStory/fuji/desktop/video-devices-in.m4v"
        ></video>
      </div>
      <hr
        style={{
          Color: "gray",
          height: "5px",
          backgroundColor: "grey",
          marginTop: "0px",
        }}
      />
      <div style={{ backgroundColor: "black", color: "white", height:"200px", marginTop:"-9px" }}>
        <div style={{ fontSize: "20px", marginLeft: "450px", color: "grey" }}>
          <b>Create profiles for kids</b>
        </div>
        <div style={{ fontSize: "10px", marginLeft: "450px"}}>
          Send children on adventures with their favourite characters
          <br />
          in a space made just for them—free with your membership.
        </div>
        <img
          src="https://occ-0-4344-2164.1.nflxso.net/dnm/api/v6/19OhWN2dO19C9txTON9tvTFtefw/AAAABVr8nYuAg0xDpXDv0VI9HUoH7r2aGp4TKRCsKNQrMwxzTtr-NlwOHeS8bCI2oeZddmu3nMYr3j9MjYhHyjBASb1FaOGYZNYvPBCL.png?r=54d"
          alt="Kids"
          style={{ height: "150px", marginTop: "-40px", marginLeft: "130px"}}
        />
        <hr
        style={{
          Color: "gray",
          height: "5px",
          backgroundColor: "grey",
          marginTop: "0px",
        }}
      />
      </div>
    </>
  );
}
