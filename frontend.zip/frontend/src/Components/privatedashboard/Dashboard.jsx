import React, { useEffect, useState } from "react";
import { Button, Modal } from "antd";
import axios from "axios";
import swal from "sweetalert";
import InputField from "../../CommonCompents/InputField";
import { useNavigate } from "react-router-dom";
export default function Dashboard() {
  const navigate=useNavigate();
  const [data, setData] = useState([]);
  const [open, setOpen] = useState(true);
  const [passcode, setPasscode] = useState("");
  const [clickLimit, setClickLimit] = useState(0);
  const email = localStorage.getItem("email");
  
  const showModal = () => {
    setOpen(true);
  };
  const handleOk = (e) => {
    setClickLimit(clickLimit+1);
    if(clickLimit>=3){
      alert("you have reached higher limit");
    }
    console.log(e);
    console.log("dob", passcode);
    const formData = new FormData();
    formData.append("passcode", passcode);
    axios
      .post(`http://localhost:8000/userPasscode/${email}`, formData)
      .then((res) => {
        console.log("backend res", res);
        if (res.data.status == 1) {
          swal({
            position: "center",
            icon: "success",
            title: res.data.message,
            // showConfirmButton: false,
            timer: 3000,
          });
          setOpen(false);
        } else {
          swal({
            position: "center",
            icon: "warning",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        console.log("backend error", error);
      });
    return;
    setOpen(false);
  };
  console.log("clickLimit",clickLimit);
    const handleCancel = (e) => {
    console.log(e);
    setOpen(false);
    handleLogout();
  };
  const handleLogout = async () => {
    console.log("working");
    localStorage.removeItem("email");
    navigate("/login");
  };
  const getData = async () => {
    const url =
      "https://youtube138.p.rapidapi.com/playlist/videos/?id=PLcirGkCPmbmFeQ1sm4wFciF03D_EroIfr&hl=en&gl=US";
    const options = {
      method: "GET",
      headers: {
        "X-RapidAPI-Key": "02e8121978msh6717b8cab51e91dp1fce7bjsn1cd4af6c4c36",
        "X-RapidAPI-Host": "youtube138.p.rapidapi.com",
      },
    };

    try {
      const response = await fetch(url, options);
      // console.log("response: ",response.json());
      const result = response;
      // console.log(await result.json());
      const videoData = await result.json();
      // console.log(await result.json());

      setData(videoData?.contents);
    } catch (error) {
      console.error(error);
    }
  };

  console.log("data", data);
  // useEffect(() => {
  //   getData();
  // }, []);
  return (
    <div>
      {data?.lenght > 0 ? (
        data?.map((d, index) => {
          return <h1>{d?.type}</h1>;
        })
      ) : (
        <div className="w-[500px] h-[400px] mt-5">
          Dashboard
          {/* <Button type="primary" onClick={showModal}>
        Open Modal with customized button props
      </Button> */}
          <Modal
            title="Enter Passcode"
            open={open}
            onOk={handleOk}
            onCancel={handleCancel}
            okButtonProps={{
              disabled: passcode?.length > 0 ? false : true,
            }}
            cancelButtonProps={{
              disabled: false,
            }}
          >
            <InputField
              title="Passcode"
              placeholder="Enter your Passowrd"
              type="date"
              onChange={(e) => {
                setPasscode(e.target.value);
              }}
            />
          </Modal>
        </div>
      )}
    </div>
  );
}
