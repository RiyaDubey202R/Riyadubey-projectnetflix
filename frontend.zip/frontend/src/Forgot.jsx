import axios from "axios";
import React, { useState } from "react";
import swal from "sweetalert";
import {useNavigate} from "react-router-dom"
export default function Forgot() {
  const navigate=useNavigate();
  const [email, setEmail] = useState("");
  const [verify, setVerify] = useState(false);

  const [otp, setOtp] = useState();
  const [password, setPassword] = useState("");

  const [cp, setCp] = useState("");

  const [isOtp, setIsOtp] = useState(false);
  const [message,setMessage]= useState("");
  const handleOtp = () => {
    const formData = new FormData();
    formData.append("username", email);
    console.log("otp generate button is working fine .");
    axios
      .post("http://localhost:8000/forget", formData)
      .then((res) => {
        console.log("backend success response!", res);
        if (res.data.status == 1) {
          setIsOtp(true);
          swal({
            position: "center",
            icon: "success",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
        } else {
          swal({
            position: "center",
            icon: "warning",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        console.log("backend failed error!", error);
      });
  };

  const handleReset = () => {
    const formData = new FormData();
    formData.append("username", email);
    formData.append("password", password);
    formData.append("cp", cp);
    console.log("otp generate button is working fine .");
    axios
      .post("http://localhost:8000/reset-password", formData)
      .then((res) => {
        console.log("backend success response!", res);
        if (res.data.status == 1) {
          swal({
            position: "center",
            icon: "success",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
          //navigate to login page again
          navigate("/login");
        } else {
          swal({
            position: "center",
            icon: "warning",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        console.log("backend failed error!", error);
      });
  };

  const handleVerify = () => {
    const formData = new FormData();
    formData.append("username", email);
    formData.append("otp", otp);
    console.log("otp generate button is working fine .");
    axios
      .post("http://localhost:8000/otp-verify", formData)
      .then((res) => {
        console.log("backend success response!", res);
        if (res.data.status == 1) {
          // setIsOtp(true);
          setVerify(true);
          swal({
            position: "center",
            icon: "success",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
        } else {
          swal({
            position: "center",
            icon: "warning",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
        }
      })
      .catch((error) => {
        console.log("backend failed error!", error);
      });
  };

  const handleCp = (e) => {
    setCp(e.target.value);
    if (password == e.target.value) {
      console.log("Matched");
      setMessage("Matched");
    } else {
      console.log("Did not Matched");
      setMessage("Did not Matched");
    }
  };
  return (
    <div>
      Forgot password
      <br />
      <label htmlFor="email">email</label>
      <input
        type="text"
        value={email}
        name="email"
        onChange={(e) => setEmail(e.target.value)}
        disabled={verify ? true : false}
      ></input>
      <br />
      {isOtp ? (
        <>
          <label htmlFor="otp">otp</label>
          <input
            type="text"
            value={otp}
            name="otp"
            onChange={(e) => setOtp(e.target.value)}
            disabled={verify ? true : false}
          ></input>
        </>
      ) : (
        ""
      )}
      <br />
      {verify ? (
        <>
          <label htmlFor="password">password</label>
          <input
            type="password"
            value={password}
            name="password"
            onChange={(e) => setPassword(e.target.value)}
          ></input>
          <br />
          <label htmlFor="cp">cp</label>
          <input type="text" value={cp} name="cp" onChange={handleCp}></input>
        </>
      ) : (
        ""
      )}
      <p style={{ color:"red"}}>{message}</p>
      <br />
      <button onClick={isOtp ?verify?handleReset: handleVerify : handleOtp}>
        {isOtp ?verify?"Reset": "Verify" : "Generate otp"}
      </button>
    </div>
  );
}
