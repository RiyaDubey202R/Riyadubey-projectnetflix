import React, { Component } from 'react'

export default class ClassChild extends Component {
    constructor(props) {
        super(props)
        console.log("ClassChild props: ", typeof props,props.email);
        this.state = {name:"hello",email:props.email};
    }
    static getDerivedStateFromProps(props) {
        return {name:props.name}
    }
    componentDidMount(){
        setTimeout(()=>{
             this.setState({name:"bye",email:"bye@email.com"});
        },2000)
    }
  render() {
    return (
      <div>ClassChild

        <h1>child name is={this.state.name}</h1>
        <h1>child email is={this.state.email}</h1>

      </div>
    )
  }
}