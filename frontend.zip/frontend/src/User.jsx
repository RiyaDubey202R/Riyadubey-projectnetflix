import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { Card, Popconfirm, message, Modal } from "antd";
import swal from "sweetalert";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import api from "./utils/api";
export default function User() {
  const { email } = useParams();
  const [user, setUser] = useState([]);
  const [isDelete, setIsDelete] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [lastName, setLastName] = useState("");
  const [firstName, setFirstName] = useState("");
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk =async() => {
    console.log("edit api call");
    const formData = new FormData();
    formData.append("firstname", firstName);
    formData.append("lastname", lastName);
    const url=`http://localhost:8000/updateUserDetails/${email}`
    const res=await api(url,formData);//1
    console.log("res",res);
    if(res==1){
      setIsModalOpen(false);
      setIsEdit(true);
    }
    else{
      setIsModalOpen(true);
    }
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const confirm = (e) => {
    console.log(e);
    message.success("Click on Yes");
    handleDelete();
  };
  const cancel = (e) => {
    console.log(e);
    message.error("Click on No");
  };
  const handleDelete = () => {
    console.log("delete working fine");
    axios
      .get(`http://localhost:8000/userDelete/${email}`)
      .then((res) => {
        console.log("backend response: ", res?.data?.data);
        if (res.data.status == 1) {
          swal({
            position: "center",
            icon: "success",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
          setIsDelete(true);
        } else {
          swal({
            position: "center",
            icon: "warning",
            title: res.data.message,
            showConfirmButton: false,
            timer: 3000,
          });
        }
      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };
  const getAllUsersDetails = async () => {
    axios
      .get(`http://localhost:8000/getUserDetails/${email}`)
      .then((res) => {
        console.log("backend response: ", res?.data?.data);
        const us = [res?.data?.data];
        setUser(us);
        setLastName(us[0]?.lastname);
        setFirstName(us[0]?.firstname);
      })
      .catch((err) => {
        console.log("backend error: ", err);
      });
  };
  useEffect(() => {
    getAllUsersDetails();
  }, [isDelete,isEdit]);
  return (
    <div>
      <Modal
        title="User Edit"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <label htmlFor="firstname">First name </label>
        <input
          type="text"
          value={firstName}
          onChange={(e) => {
            setFirstName(e.target.value);
          }}
        ></input>
        <br />
        <br />
        <label htmlFor="lastname">Last name </label>
        <input
          type="text"
          value={lastName}
          onChange={(e) => {
            setLastName(e.target.value);
          }}
        ></input>
      </Modal>
      <h1>params id:-{email}</h1>
      {user?.map((item, index) => {
        return (
          <>
            <Card
              size="small"
              title="User Details"
              style={{
                width: 300,
              }}
            >
              <p>
                name <b>{item?.firstname}</b>
              </p>
              <p>
                last name <b>{item?.lastname}</b>
              </p>
              <p>
                email <b>{item?.email}</b>
              </p>
              <div>
                <Popconfirm
                  title="Delete the task"
                  description="Are you sure to delete this task?"
                  onConfirm={confirm}
                  onCancel={cancel}
                  okText="Yes"
                  cancelText="No"
                >
                  <button>
                    <DeleteOutlined />
                  </button>
                </Popconfirm>
                <button style={{ marginLeft: "15px" }} onClick={showModal}>
                  <EditOutlined />
                </button>
              </div>
            </Card>
          </>
        );
      })}
    </div>
  );
}