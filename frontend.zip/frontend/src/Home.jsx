import React, { useEffect } from 'react'
import { useHref, useNavigate } from 'react-router-dom'

export default function Home() {
  const navigate=useNavigate();
  const email=localStorage.getItem('email');
  useEffect(()=>{
    if(email){
      navigate("/dashboard")
    }
  })
  return (
    
    <>
    <div style={{height:"500px", backgroundImage:`url("https://help.nflxext.com/43e0db2f-fea0-4308-bfb9-09f2a88f6ee4_what_is_netflix_1_en.png")`, backgroundSize:"cover"}}>
    <center><marquee behavior="scroll" direction=""><div style={{color:"white", fontSize:"20px", marginTop:"100px", marginLeft:"60px"}}><b>Unlimited movies, TV shows and more</b></div></marquee>
    <div style={{backgroundColor:"black"}}><div style={{color:"white", marginTop:"-8px", fontSize:"10px"}}>Watch anywhere. Cancel anytime.<br />Ready to watch? Enter your email to create or restart your membership.</div></div>
    <input style={{fontSize:"10px", background:"black", color:"white"}} type="text" placeholder='Email Address'/>&nbsp;
    <button style={{backgroundColor:"red", color:"white", fontSize:"10px"}}>Get Started {">"}</button></center>
    </div>
    </>
  )
}