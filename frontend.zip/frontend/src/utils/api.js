import axios from "axios";
import swal from "sweetalert";
export default async function api(url,data){
    return new Promise((resolve,reject)=>{
        try{
            axios
            .post(url, data)
            .then((response) => {
              if (response.data.status == 1) {
                console.log("backend success response", response.data.message);
                swal({
                  position: "center",
                  icon: "success",
                  title: response.data.message,
                  showConfirmButton: false,
                  timer: 3000,
                });
                return resolve(response?.data?.status);
              } else {
                console.log("backend success response", response.data.message);
                swal({
                  position: "center",
                  icon: "warning",
                  title: response.data.message,
                  showConfirmButton: false,
                  timer: 3000,
                });
              }
              return resolve(response?.data?.status);
            })
            .catch((error) => {
              console.log("backend error", error);
            });
        }
        catch(e){
        }
    })
}